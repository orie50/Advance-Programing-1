#include "LuxTaxi.h"

/******************************************************************************
* The function Operation: return the number of steps that the lux taxi do in
* one time passed
******************************************************************************/
int LuxTaxi::getVelocity() {
    return 2;
}
