//
// Created by ori on 28/11/16.
//

#ifndef ASS2_PASSENGER_H
#define ASS2_PASSENGER_H
#include <time.h>
#include <cstdlib>
/******************************************************************************
* Passenger: the passengers of the trip, at the end ofthe trip give a
* satisfication value
******************************************************************************/
class Passenger {
public:
    Passenger(){};
    int satisfacation();
};


#endif //ASS2_PASSENGER_H
