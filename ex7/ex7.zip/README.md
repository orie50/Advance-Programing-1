#we did the original exercise instruction
#we did the bonus part: the size of the map is given thourgh the server up to 10*10.
#there is total of 5 taxi images. so if there will be more than 5 drivers the images will be the same.
#drivers input is given one by one.
